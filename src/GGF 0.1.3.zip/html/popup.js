chrome.runtime.setUninstallURL('https://docs.google.com/forms/d/e/1FAIpQLSfFC4DsAw2UM_Lrh-oYVjYNQOoRr4_c5Hxzz9WQq9SxwBatZw/viewform')
